<?php

namespace App\Http\Controllers;

use App\User;
use App\Http\Requests\UserRequest;
use App\Models\Groups;
use App\Models\UserAccess;
use App\Models\ProductCategories;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    
    public function index(User $model)
    {
        $groups = Groups::get();
        return view('users.index', ['users' => $model->paginate(15), 'groups' => $groups]);
    }

    
    public function create()
    {
        $groups = Groups::get();
        $categories = ProductCategories::get();
        return view('users.create', ['groups' => $groups, 'categories' => $categories]);
    }

    
    public function store(UserRequest $request, User $model)
    {
        $categories = ProductCategories::get();
        $user = $model->create($request->merge(['password' => Hash::make($request->get('password')),
                                        'group_id' => $request->group,
                                        'business_name' => $request->businessName,
                                        'post_code' => $request->postCode,
                                        'address' => $request->address,
                                        'phone' => $request->phone,
                                        'lat' => $request->lat,
                                        'lng' => $request->long,
                                        'mobile' => $request->mobile])->all());
        foreach($categories as $category){
            if($request->has('cat-'.$category->id)){
                $data = [
                    'user_id' => $user->id,
                    'category_id' => $category->id
                ];
                UserAccess::create($data);
            }
        }
        return redirect()->route('user.index')->withStatus(__('User successfully created.'));
    }

    
    public function edit(User $user)
    {
        $groups = Groups::get();
        // $user = User::with('group')->get();
        return view('users.edit', compact('user'), compact('groups'));
    }

    
    public function update(UserRequest $request, User  $user)
    {
        $user->update(
            $request->merge(['password' => Hash::make($request->get('password')),'group_id' => $request->group,
                                        'business_name' => $request->businessName,
                                        'post_code' => $request->postCode,
                                        'address' => $request->address,
                                        'phone' => $request->phone,
                                        'lat' => $request->lat,
                                        'lng' => $request->long,
                                        'mobile' => $request->mobile
            ])->except([$request->get('password') ? '' : 'password']
        ));

        return redirect()->route('user.index')->withStatus(__('User successfully updated.'));
    }

   
    public function destroy(User  $user)
    {
        $user->delete();

        return redirect()->route('user.index')->withStatus(__('User successfully deleted.'));
    }
}
