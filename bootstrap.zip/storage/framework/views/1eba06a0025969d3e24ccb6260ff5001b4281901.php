<?php $__env->startSection('content'); ?>
<div class="flex-center position-ref full-height">

<!-- <div class="content"> -->
<section class="login-block">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="container">
                    <div class="row">
                        
                        <div class="col-md-7 banner-sec">
                        </div>
                        <div class="col-md-5 login-sec">
                            <div class="login-logo text-center">
                                <img src="<?php echo e(asset('images/mobile-logo.png')); ?>">
                            </div>
                            <h2 class="text-center">Login Now</h2>
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleInputEmail1" class="text-uppercase">Username</label>
                                    <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Email')); ?>" type="email" name="email"
                                        value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>

                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1" class="text-uppercase">Password</label>
                                    <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                        name="password" placeholder="<?php echo e(__('Password')); ?>" type="password" required>

                                    <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>


                                <div class="">
                                    <button type="submit" class="btn w-100 btn-login">Submit</button>
                                </div>

                            </form>
                            <div class="copy-text"><a href="https://magicsalt.co">Magic Salt</a> <i class="far fa-copyright"></i>  2018 </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


</section>

<!-- </div> -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\magic-salt\resources\views/auth/login.blade.php ENDPATH**/ ?>